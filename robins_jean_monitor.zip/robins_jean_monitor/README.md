# Robin's Jean Listing Monitor (Discord)

A small cloud-ready Python worker that checks eBay's official Browse API for newly listed Robin's Jean items and posts new matches to a Discord webhook. It stores seen item IDs in SQLite to avoid duplicate alerts.

## Important access notes

- **eBay:** Requires an eBay Developer account and Browse API application credentials (Client ID and Client Secret). The bot uses the official Browse API and `sort=newlyListed`.
- **Depop:** Not enabled by default. Depop's API is private and its published terms prohibit automated scraping unless Depop expressly authorizes it in writing. Do not use browser scraping or undocumented endpoints. If you receive authorized API access, implement the adapter using the documentation and credentials Depop provides.
- **Speed:** Defaults to checking eBay every 60 seconds. API limits, host scheduling, network errors, and listing indexing can delay alerts. This is not a guaranteed instant feed.
- **Hosting:** Intended for a continuously running worker on Railway, Render, Fly.io, or another Python worker host with persistent storage. Attach a persistent volume for `/data` so SQLite deduplication survives restarts.

## 1. Create a Discord webhook

In your Discord server:
1. Open the channel where alerts should appear.
2. Edit Channel → Integrations → Webhooks → New Webhook.
3. Copy the webhook URL. Treat it like a password; do not share it publicly.

## 2. Get eBay API credentials

1. Create/sign in to an account at https://developer.ebay.com/
2. Create an application keyset and copy the **Production** Client ID and Client Secret (or use Sandbox credentials for testing).
3. The app uses client-credentials OAuth for a public search. If eBay restricts your application or API access, follow its developer program requirements.

## 3. Configure environment variables

Set these variables in your cloud host's secret/environment settings:

- `EBAY_CLIENT_ID` = your eBay Production Client ID
- `EBAY_CLIENT_SECRET` = your eBay Production Client Secret
- `DISCORD_WEBHOOK_URL` = your Discord webhook URL
- `POLL_SECONDS` = `60` (increase if needed)
- `DATABASE_PATH` = `/data/seen.sqlite3` (recommended when `/data` is a persistent volume)
- `EBAY_MARKETPLACE_ID` = `EBAY_US`
- `SEARCH_QUERIES` = `Robin's Jean|Robins Jean|Robin Jeans|Robins Jeans`

Never put real credentials in source code or commit them to Git.

## 4. Deploy as a cloud worker

A simple option is a Railway Python service:
1. Create a new project and deploy this folder/repository.
2. Use the start command: `python -m bot.main`
3. Add the environment variables above as secrets.
4. Attach a persistent volume mounted at `/data`.
5. Confirm logs show successful eBay searches and that a test alert appears in Discord.

This worker is designed to run continuously. Do not deploy it as a serverless function that stops between requests.

## 5. Test locally (optional)

Python 3.11+ recommended.

```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
copy .env.example .env  # Windows, or cp .env.example .env on macOS/Linux
# Fill in .env, then:
python -m bot.main
```

The app reads environment variables automatically from `.env` for local use.

## What it matches

Searches each phrase separately, newest first, then combines results and deduplicates by eBay item ID. Search phrase matching is intentionally broad; refine `SEARCH_QUERIES` if false positives appear. The eBay API can return older results among the first page, so the bot uses item IDs plus first-run seeding to avoid blasting old listings.

### First run behavior

By default, the first successful scan **seeds the database without posting alerts**, preventing a flood of old active listings. Later scans post newly discovered IDs. Set `ALERT_ON_FIRST_RUN=true` only if you want every result on the initial scan sent to Discord.

## Depop integration

The code deliberately does not scrape Depop. If you obtain written authorization and API credentials, add a provider module that uses the exact authorized endpoint and response schema Depop supplies. Until then, Depop is not monitored by this bot.
