import base64
import logging
import os
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote

import requests
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s %(message)s",
)
log = logging.getLogger("robins-monitor")

CLIENT_ID = os.getenv("EBAY_CLIENT_ID", "").strip()
CLIENT_SECRET = os.getenv("EBAY_CLIENT_SECRET", "").strip()
WEBHOOK = os.getenv("DISCORD_WEBHOOK_URL", "").strip()
POLL_SECONDS = max(60, int(os.getenv("POLL_SECONDS", "60")))
DB_PATH = os.getenv("DATABASE_PATH", "seen.sqlite3")
MARKETPLACE = os.getenv("EBAY_MARKETPLACE_ID", "EBAY_US")
QUERIES = [q.strip() for q in os.getenv(
    "SEARCH_QUERIES",
    "Robin's Jean|Robins Jean|Robin Jeans|Robins Jeans"
).split("|") if q.strip()]
ALERT_ON_FIRST_RUN = os.getenv("ALERT_ON_FIRST_RUN", "false").lower() in {"1", "true", "yes"}

TOKEN_URL = "https://api.ebay.com/identity/v1/oauth2/token"
SEARCH_URL = "https://api.ebay.com/buy/browse/v1/item_summary/search"
USER_AGENT = "RobinsJeanListingMonitor/1.0"


def db_connect():
    path = Path(DB_PATH)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS seen_items (
            item_id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            item_url TEXT NOT NULL,
            first_seen_utc TEXT NOT NULL
        )
    """)
    conn.commit()
    return conn


def get_access_token():
    if not CLIENT_ID or not CLIENT_SECRET:
        raise RuntimeError("Set EBAY_CLIENT_ID and EBAY_CLIENT_SECRET environment variables.")
    basic = base64.b64encode(f"{CLIENT_ID}:{CLIENT_SECRET}".encode()).decode()
    response = requests.post(
        TOKEN_URL,
        headers={
            "Authorization": f"Basic {basic}",
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": USER_AGENT,
        },
        data={
            "grant_type": "client_credentials",
            "scope": "https://api.ebay.com/oauth/api_scope",
        },
        timeout=25,
    )
    response.raise_for_status()
    return response.json()["access_token"]


def ebay_search(token, query):
    response = requests.get(
        SEARCH_URL,
        headers={
            "Authorization": f"Bearer {token}",
            "X-EBAY-C-MARKETPLACE-ID": MARKETPLACE,
            "User-Agent": USER_AGENT,
        },
        params={
            "q": query,
            "sort": "newlyListed",
            "limit": 50,
        },
        timeout=30,
    )
    response.raise_for_status()
    payload = response.json()
    return payload.get("itemSummaries", [])


def canonical_item(item):
    item_id = item.get("itemId")
    if not item_id:
        return None
    title = item.get("title") or "Robin's Jean listing"
    url = item.get("itemWebUrl") or ""
    price_obj = item.get("price") or {}
    price = price_obj.get("value")
    currency = price_obj.get("currency")
    image_obj = item.get("image") or {}
    image = image_obj.get("imageUrl")
    # Include product-level details only when returned by the official API.
    return {
        "id": item_id,
        "title": title[:250],
        "url": url,
        "price": f"{currency} {price}" if currency and price else (str(price) if price else "Price not returned"),
        "image": image,
        "condition": item.get("condition"),
        "seller": (item.get("seller") or {}).get("username"),
        "query": "",
    }


def discord_alert(item):
    if not WEBHOOK:
        raise RuntimeError("Set DISCORD_WEBHOOK_URL environment variable.")
    embed = {
        "title": item["title"][:250],
        "url": item["url"] or "https://www.ebay.com/",
        "description": f"**Price:** {item['price']}\n"
                       f"**Marketplace:** eBay\n"
                       f"**Search match:** {item.get('query', 'Robin’s Jean')}",
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    if item.get("image"):
        embed["thumbnail"] = {"url": item["image"]}
    if item.get("condition"):
        embed["footer"] = {"text": f"Condition: {item['condition']}"}
    response = requests.post(
        WEBHOOK,
        json={"username": "Robin's Jean Monitor", "embeds": [embed]},
        timeout=20,
    )
    response.raise_for_status()


def scan_once(conn, token, seeded):
    results = {}
    for query in QUERIES:
        try:
            items = ebay_search(token, query)
            log.info("eBay query %r returned %d items", query, len(items))
            for raw in items:
                item = canonical_item(raw)
                if item:
                    item["query"] = query
                    # First result for an ID wins; one alert per listing across all terms.
                    results.setdefault(item["id"], item)
        except requests.HTTPError as exc:
            status = exc.response.status_code if exc.response is not None else "unknown"
            body = exc.response.text[:500] if exc.response is not None else str(exc)
            log.error("eBay search failed for %r (HTTP %s): %s", query, status, body)
        except requests.RequestException as exc:
            log.error("eBay search network error for %r: %s", query, exc)

    if not results:
        return seeded

    # On the very first successful nonempty scan, seed existing results by default.
    existing_count = conn.execute("SELECT COUNT(*) FROM seen_items").fetchone()[0]
    first_seed = existing_count == 0 and not seeded and not ALERT_ON_FIRST_RUN
    new_items = []
    now = datetime.now(timezone.utc).isoformat()

    for item in results.values():
        cursor = conn.execute(
            "INSERT OR IGNORE INTO seen_items(item_id,title,item_url,first_seen_utc) VALUES(?,?,?,?)",
            (item["id"], item["title"], item["url"], now),
        )
        if cursor.rowcount == 1 and not first_seed:
            new_items.append(item)
    conn.commit()

    if first_seed:
        log.info("Initial seed saved %d existing listing IDs; no alerts sent on first scan.", len(results))
        return True

    # The official API does not guarantee indexing delay/ordering; notify each new unique ID.
    for item in new_items:
        try:
            discord_alert(item)
            log.info("Alert sent for item %s: %s", item["id"], item["title"])
            time.sleep(1.0)  # gentle spacing for Discord webhook limits
        except requests.HTTPError as exc:
            status = exc.response.status_code if exc.response is not None else "unknown"
            log.error("Discord webhook failed (HTTP %s): %s", status, exc)
        except requests.RequestException as exc:
            log.error("Discord webhook network error: %s", exc)
    if not new_items:
        log.info("No new eBay listing IDs.")
    return True


def main():
    if not WEBHOOK:
        raise RuntimeError("Set DISCORD_WEBHOOK_URL before starting.")
    conn = db_connect()
    seeded = False
    log.info("Starting Robin's Jean monitor. Queries=%s poll=%ss marketplace=%s", QUERIES, POLL_SECONDS, MARKETPLACE)
    log.warning("Depop monitoring is disabled: use only an explicitly authorized Depop API integration.")
    while True:
        try:
            token = get_access_token()
            seeded = scan_once(conn, token, seeded)
        except requests.HTTPError as exc:
            status = exc.response.status_code if exc.response is not None else "unknown"
            body = exc.response.text[:500] if exc.response is not None else str(exc)
            log.error("eBay OAuth/API error (HTTP %s): %s", status, body)
        except Exception:
            log.exception("Unexpected scan error")
        time.sleep(POLL_SECONDS)


if __name__ == "__main__":
    main()
